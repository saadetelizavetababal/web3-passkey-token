#![no_std] // Standart kütüphane bağımlılıklarını devre dışı bırak
use soroban_sdk::{contract, contractimpl, contracttype, symbol_short, Address, Env, Map, Symbol, Vec};

// Kontratın depolama (storage) türlerini tanımla
#[contracttype]
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum DataKey {
    // Tüm sertifikaları saklamak için genel bir harita.
    // Anahtar: Public Key (Address), Değer: Sertifikaların Vector'ü
    Certificates,
}

// Sertifika yapısı
#[contracttype]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Certificate {
    pub id: u32,
    pub recipient_name: Symbol,
    pub course_name: Symbol,
    pub institution_name: Symbol,
    pub issue_date: Symbol,
}

// Kontrat arayüzü (public fonksiyonlar)
#[contract]
pub struct CertificateContract;

#[contractimpl]
impl CertificateContract {
    /// Yeni bir sertifika basar ve alıcının hesabına kaydeder.
    ///
    /// # Parametreler
    /// - `env`: Soroban çalışma ortamı.
    /// - `recipient`: Sertifikayı alacak olan hesabın adresi.
    /// - `recipient_name`: Sertifika sahibinin adı.
    /// - `course_name`: Kursun adı.
    /// - `institution_name`: Kurumun adı.
    /// - `issue_date`: Veriliş tarihi (örneğin "2025-06-21").
    ///
    /// # Yetkilendirme (Auth)
    /// Bu fonksiyonu çağıran adresin (`issuer` gibi) işlemi imzalaması gerekir.
    pub fn mint(
        env: Env,
        recipient: Address,
        recipient_name: Symbol,
        course_name: Symbol,
        institution_name: Symbol,
        issue_date: Symbol,
    ) -> u32 {
        // Fonksiyonu çağıranın (genellikle issuer) yetkili olduğunu doğrula
        // Gerçek bir senaryoda buraya daha karmaşık yetkilendirme logic'i ekleyebilirsiniz.
        // Şimdilik sadece çağrının yapılması yeterli.
        env.invoke_contract(&env.current_contract_address(), &symbol_short!("require_auth"), &Vec::new(&env));

        let mut certificates_map: Map<Address, Vec<Certificate>> = env
            .storage()
            .persistent()
            .get(&DataKey::Certificates)
            .unwrap_or_else(|| Map::new(&env));

        let mut recipient_certs = certificates_map
            .get(&recipient)
            .unwrap_or_else(|| Vec::new(&env));

        let next_id = recipient_certs.len() + 1; // Basit bir ID atama

        let new_certificate = Certificate {
            id: next_id,
            recipient_name,
            course_name,
            institution_name,
            issue_date,
        };

        recipient_certs.push_back(new_certificate);
        certificates_map.set(&recipient, recipient_certs);
        env.storage().persistent().set(&DataKey::Certificates, &certificates_map);

        next_id
    }

    /// Belirli bir cüzdan adresine ait tüm sertifikaları getirir.
    /// Bu bir "view" (sadece okuma) fonksiyonudur ve işlem ücreti gerektirmez (sadece simülasyon).
    ///
    /// # Parametreler
    /// - `env`: Soroban çalışma ortamı.
    /// - `wallet_address`: Sertifikaları sorgulanacak olan hesabın adresi.
    ///
    /// # Dönüş
    /// Belirtilen adrese kayıtlı sertifikaların bir Vector'ü.
    pub fn get_certificates(env: Env, wallet_address: Address) -> Vec<Certificate> {
        let certificates_map: Map<Address, Vec<Certificate>> = env
            .storage()
            .persistent()
            .get(&DataKey::Certificates)
            .unwrap_or_else(|| Map::new(&env));

        certificates_map
            .get(&wallet_address)
            .unwrap_or_else(|| Vec::new(&env))
    }
}
