const express = require('express');
const router = express.Router();
const StellarSdk = require('@stellar/stellar-sdk');
// DÜZELTME: SorobanRpc.Server yerine Server'ı doğrudan import ediyoruz
const { Server, scValToNative, xdr } = require('soroban-client');

// .env dosyasından ortam değişkenlerini yükle
require('dotenv').config();

// Stellar ağı yapılandırması
const SOROBAN_RPC_URL = process.env.SOROBAN_RPC;
const NETWORK_PASSPHRASE = process.env.NETWORK_PASSPHRASE;
const CONTRACT_ID = process.env.CONTRACT_ID;

// RPC istemcisini başlat
// DÜZELTME: new SorobanRpc.Server yerine new Server kullanıyoruz
const server = new Server(SOROBAN_RPC_URL);

router.get('/:walletAddress', async (req, res) => {
    const { walletAddress } = req.params;

    // Cüzdan adresinin geçerliliğini kontrol et
    if (!StellarSdk.StrKey.isValidEd25519PublicKey(walletAddress)) {
        return res.status(400).json({ success: false, message: 'Geçersiz Stellar cüzdan adresi.' });
    }

    try {
        // Kontrattan sertifikaları almak için 'get_certificates' view fonksiyonunu çağır
        // Bu fonksiyonun, verilen cüzdan adresine ait tüm sertifikaları döndürdüğünü varsayıyoruz.
        // Kontratınızdaki fonksiyon imzasına göre burayı düzenlemeniz gerekmektedir.
        const operation = StellarSdk.Operation.invokeHostFunction({
            function: new xdr.HostFunction.hostFunctionTypeInvokeContract(
                new xdr.ScContractId.scContractIdFromBytes(
                    StellarSdk.StrKey.decodeContract(CONTRACT_ID)
                ),
                new xdr.ScSymbol('get_certificates'), // Kontratınızdaki sorgulama fonksiyonunun adı
                new xdr.ScVec([
                    // walletAddress'i ScAddress olarak geçiriyoruz (public key)
                    new xdr.ScVal.scvAddress(xdr.ScAddress.scAddressTypeAccountId(StellarSdk.Keypair.fromPublicKey(walletAddress).xdrAccountId()))
                ])
            ),
            auth: [] // View fonksiyonları (veri okuma) genellikle yetkilendirme (auth) gerektirmez
        });

        // Simülasyon işlemi oluştur. View fonksiyonları sadece simüle edilerek çağrılır, zincire gönderilmez.
        // Sadece simülasyon için dummy bir kaynak hesap kullanıyoruz, önemli değil.
        const dummySourceAccount = new StellarSdk.Account(walletAddress, '-1');
        let transaction = new StellarSdk.TransactionBuilder(dummySourceAccount, {
            fee: '100000', // Simülasyon için varsayılan ücret
            networkPassphrase: NETWORK_PASSPHRASE,
        })
        .addOperation(operation)
        .setTimeout(StellarSdk.TimeoutInfinite)
        .build();

        // İşlemi simüle et (kontratın dönüş değerini almak için)
        const simulateResult = await server.simulateTransaction(transaction);

        if (simulateResult.error) {
            console.error('Verify Simülasyon Hatası:', simulateResult.error);
            // Simülasyon hatasının detayını kullanıcıya gönder
            return res.status(500).json({ success: false, message: `Sertifika doğrulama simülasyon hatası: ${simulateResult.error.diagnosticEvents?.map(e => e.event.body().debug().toString()).join('\n') || simulateResult.error.message}` });
        }

        // Kontrat dönüş değerini kontrol et
        if (!simulateResult.result || !simulateResult.result.retval) {
            // Kontrat bir değer döndürmediyse veya beklenen format değilse
            return res.status(404).json({ success: false, message: 'Bu adrese kayıtlı sertifika bulunamadı veya kontrat beklenen değeri döndürmedi.' });
        }

        // scValToNative kullanarak kontratın döndürdüğü değeri JS tipine dönüştür
        // Kontratınızın bir ARRAY<Map<Symbol, ScVal>> veya benzeri bir yapı döndürdüğünü varsayıyoruz.
        // Örneğin: [{id: "...", name: "...", course: "..."} gibi JS objeleri]
        const rawCertificates = simulateResult.result.retval;
        const certificates = scValToNative(rawCertificates);

        console.log('Doğrulama başarılı. Alınan sertifikalar:', certificates);
        res.status(200).json(certificates);

    } catch (err) {
        console.error('Verify işlemi sırasında hata oluştu:', err);
        let errorMessage = 'Doğrulama işlemi başarısız: Sunucu hatası.';
        if (err.response && err.response.data) {
            errorMessage = `Doğrulama işlemi başarısız: Stellar RPC hatası - ${err.response.data.detail || err.response.data.title || JSON.stringify(err.response.data)}`;
        } else if (err instanceof Error) {
            errorMessage = `Doğrulama işlemi başarısız: ${err.message}`;
        }
        res.status(500).json({ success: false, message: errorMessage });
    }
});

module.exports = router;
