const express = require('express');
const router = express.Router();
const StellarSdk = require('@stellar/stellar-sdk');
// DÜZELTME: SorobanRpc.Server yerine Server'ı doğrudan import ediyoruz
const { Server, TransactionBuilder, scValToNative, xdr } = require('soroban-client');

// .env dosyasından ortam değişkenlerini yükle
require('dotenv').config();

// Stellar ağı yapılandırması
const SOROBAN_RPC_URL = process.env.SOROBAN_RPC;
const NETWORK_PASSPHRASE = process.env.NETWORK_PASSPHRASE;
const CONTRACT_ID = process.env.CONTRACT_ID;
const ISSUER_SECRET_KEY = process.env.ISSUER_SECRET_KEY; // Sertifikaları basacak olan hesabın gizli anahtarı

// RPC istemcisini başlat
// DÜZELTME: new SorobanRpc.Server yerine new Server kullanıyoruz
const server = new Server(SOROBAN_RPC_URL);

// Issuer hesabını yükle
let issuerAccount;
try {
    issuerAccount = StellarSdk.Keypair.fromSecret(ISSUER_SECRET_KEY);
    console.log('Issuer Public Key:', issuerAccount.publicKey());
} catch (error) {
    console.error('HATA: ISSUER_SECRET_KEY hatalı veya eksik. Lütfen .env dosyasını kontrol edin.');
    process.exit(1); // Uygulamayı sonlandır
}

router.post('/', async (req, res) => {
    const { recipientName, courseName, institutionName, issueDate, recipientAddress } = req.body;

    // Gerekli alanların kontrolü
    if (!recipientName || !courseName || !institutionName || !issueDate || !recipientAddress) {
        return res.status(400).json({ success: false, message: 'Tüm alanlar zorunludur.' });
    }
    // Geçerli bir Stellar public key olup olmadığını kontrol et
    if (!StellarSdk.StrKey.isValidEd25519PublicKey(recipientAddress)) {
        return res.status(400).json({ success: false, message: 'Geçersiz alıcı cüzdan adresi (recipientAddress).' });
    }

    try {
        // Issuer hesabının güncel durumunu (sıra numarasını) al
        // Bu, işlem oluşturmak için gereklidir.
        const account = await server.getAccount(issuerAccount.publicKey());
        const sourceAccount = new StellarSdk.Account(account.id, account.sequence);

        // Soroban kontratındaki 'mint' fonksiyonunu çağırma işlemi oluştur
        // Fonksiyonun argümanları: (recipient_address: Address, recipient_name: String, course_name: String, institution_name: String, issue_date: String)
        const operation = StellarSdk.Operation.invokeHostFunction({
            function: new xdr.HostFunction.hostFunctionTypeInvokeContract(
                new xdr.ScContractId.scContractIdFromBytes(
                    StellarSdk.StrKey.decodeContract(CONTRACT_ID)
                ),
                new xdr.ScSymbol('mint'), // Kontratınızdaki mint fonksiyonunun adı
                new xdr.ScVec([
                    // Alıcı adresini ScAddress olarak dönüştür (public key'den account ID)
                    new xdr.ScVal.scvAddress(xdr.ScAddress.scAddressTypeAccountId(StellarSdk.Keypair.fromPublicKey(recipientAddress).xdrAccountId())),
                    new xdr.ScVal.scvString(recipientName),
                    new xdr.ScVal.scvString(courseName),
                    new xdr.ScVal.scvString(institutionName),
                    new xdr.ScVal.scvString(issueDate) // Tarihi string olarak gönderiyoruz
                ])
            ),
            auth: [] // Kontratınız eğer farklı bir yetkilendirme gerektiriyorsa burayı düzenlemelisiniz
        });

        // İşlemi oluştur (şimdilik varsayılan bir ücretle)
        let transaction = new StellarSdk.TransactionBuilder(sourceAccount, {
            fee: '100000', // Simülasyon öncesi varsayılan ücret
            networkPassphrase: NETWORK_PASSPHRASE,
        })
        .addOperation(operation)
        .setTimeout(StellarSdk.TimeoutInfinite) // İşlem timeout'ını sonsuz yap (test için)
        .build();

        // İşlemi simüle et. Bu adım, gerçek işlem ücretini ve olası hataları belirler.
        const simulateResult = await server.simulateTransaction(transaction);

        if (simulateResult.error) {
            console.error('Simülasyon Hatası:', simulateResult.error);
            // Simülasyon hatasının detayını kullanıcıya gönder
            return res.status(500).json({ success: false, message: `Simülasyon hatası: ${simulateResult.error.diagnosticEvents?.map(e => e.event.body().debug().toString()).join('\n') || simulateResult.error.message}` });
        }

        // Simülasyon sonucundan minimum kaynak ücretini al
        const minFee = simulateResult.minResourceFee.toString();
        console.log('Minimum Kaynak Ücreti (Min Resource Fee):', minFee);

        // İşlemi güncel, doğru ücretle yeniden oluştur
        transaction = new StellarSdk.TransactionBuilder(sourceAccount, {
            fee: minFee, // Simülasyondan gelen gerçek ücreti kullan
            networkPassphrase: NETWORK_PASSPHRASE,
        })
        .addOperation(operation)
        .setTimeout(StellarSdk.TimeoutInfinite)
        .build();

        // İşlemi issuer hesabı ile imzalama
        transaction.sign(issuerAccount);

        // İmzalanmış işlemi Stellar ağına gönder
        const transactionResult = await server.sendTransaction(transaction);

        console.log('Mint işlemi başarıyla gönderildi. Transaction Hash:', transactionResult.hash);
        res.status(200).json({
            success: true,
            transactionId: transactionResult.hash,
            message: 'Sertifika başarıyla basma işlemi gönderildi!'
        });

    } catch (err) {
        console.error('Mint işlemi sırasında hata oluştu:', err);
        let errorMessage = 'Mint işlemi başarısız: Sunucu hatası.';
        if (err.response && err.response.data) {
            // Stellar RPC'den gelen detaylı hata mesajlarını yakala
            errorMessage = `Mint işlemi başarısız: Stellar RPC Hatası - ${err.response.data.detail || err.response.data.title || JSON.stringify(err.response.data)}`;
        } else if (err instanceof Error) {
            errorMessage = `Mint işlemi başarısız: ${err.message}`;
        }
        res.status(500).json({ success: false, message: errorMessage });
    }
});

module.exports = router;
