const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const mintRoute = require('./routes/mint');
const verifyRoute = require('./routes/verify');

dotenv.config(); // .env dosyasındaki değişkenleri yükle
const app = express();

app.use(cors()); // Farklı kaynaklardan gelen isteklere izin ver (frontend için gerekli)
app.use(express.json()); // JSON body'leri parse etmek için

// API rotalarını bağla
app.use('/api/mint-certificate', mintRoute);
app.use('/api/verify-certificate', verifyRoute);

const PORT = process.env.PORT || 3001; // Varsayılan olarak 3001 portunu kullan
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

// Basit bir test endpoint'i
app.get('/', (req, res) => {
    res.send('Stellar Sertifika Backend API çalışıyor!');
});
