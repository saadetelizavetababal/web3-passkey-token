export class PasskeyAuth {
    constructor() {
        this.statusElement = document.getElementById('authStatus');
    }

    async init() {
        document.getElementById('passkeyAuthBtn').addEventListener('click', () => this.authenticate());
        document.getElementById('passwordAuthBtn').addEventListener('click', () => this.passwordFallback());
    }

    async authenticate() {
        const userIdentifier = document.getElementById('userIdentifier').value.trim();
        
        try {
            this.showStatus('Initiating passkey authentication...', 'info');
            
            // 1. Get options from server
            const options = await this.getAuthOptions(userIdentifier);
            
            // 2. Get assertion from authenticator
            const credential = await navigator.credentials.get({
                publicKey: this.transformOptions(options)
            });
            
            // 3. Verify with server
            const userData = await this.verifyAssertion(credential);
            
            // 4. Complete auth
            this.showStatus('Authentication successful!', 'success');
            this.completeAuthentication({
                method: 'passkey',
                ...userData
            });
            
        } catch (error) {
            this.showStatus(`Authentication failed: ${error.message}`, 'error');
        }
    }

    async getAuthOptions(identifier) {
        const response = await fetch('/api/auth/passkey/options', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ identifier })
        });
        
        if (!response.ok) throw new Error('Failed to get auth options');
        return response.json();
    }

    transformOptions(options) {
        // Convert server options to WebAuthn format
        return {
            ...options,
            challenge: this.base64ToArrayBuffer(options.challenge),
            allowCredentials: options.allowCredentials?.map(cred => ({
                ...cred,
                id: this.base64ToArrayBuffer(cred.id)
            }))
        };
    }

    async verifyAssertion(assertion) {
        const response = await fetch('/api/auth/passkey/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.formatAssertion(assertion))
        });
        
        if (!response.ok) throw new Error('Verification failed');
        return response.json();
    }

    formatAssertion(assertion) {
        return {
            id: assertion.id,
            rawId: this.arrayBufferToBase64(assertion.rawId),
            type: assertion.type,
            response: {
                authenticatorData: this.arrayBufferToBase64(assertion.response.authenticatorData),
                clientDataJSON: this.arrayBufferToBase64(assertion.response.clientDataJSON),
                signature: this.arrayBufferToBase64(assertion.response.signature),
                userHandle: assertion.response.userHandle 
                    ? this.arrayBufferToBase64(assertion.response.userHandle)
                    : null
            }
        };
    }

    passwordFallback() {
        // Implement password fallback logic
    }

    // Helper methods
    base64ToArrayBuffer(base64) {
        // Conversion implementation
    }

    arrayBufferToBase64(buffer) {
        // Conversion implementation
    }

    showStatus(message, type) {
        this.statusElement.textContent = message;
        this.statusElement.className = `status-message ${type}`;
    }

    completeAuthentication(userData) {
        // Trigger global auth success
        const event = new CustomEvent('authSuccess', { detail: userData });
        document.dispatchEvent(event);
    }
}