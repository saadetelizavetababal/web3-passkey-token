import { PasskeyAuth } from './passkey.js';
import { Web3Auth } from './web3.js';

class AuthApp {
    constructor() {
        this.passkeyAuth = new PasskeyAuth();
        this.web3Auth = new Web3Auth();
        this.initUI();
    }

    initUI() {
        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                
                btn.classList.add('active');
                document.getElementById(`${btn.dataset.tab}Tab`).classList.add('active');
            });
        });

        // Close modal
        document.getElementById('closeAuth').addEventListener('click', () => {
            document.getElementById('authModal').classList.add('hidden');
        });

        // Initialize auth methods
        this.passkeyAuth.init();
        this.web3Auth.init();
    }

    showAuthModal() {
        document.getElementById('authModal').classList.remove('hidden');
    }

    handleSuccessfulAuth(userData) {
        localStorage.setItem('currentUser', JSON.stringify(userData));
        document.getElementById('authModal').classList.add('hidden');
        document.getElementById('appContent').classList.remove('hidden');
        
        // Initialize main app with user data
        this.initApp(userData);
    }

    initApp(userData) {
        // Your main application initialization
        console.log('App initialized for:', userData);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const app = new AuthApp();
    
    // Check existing session
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (currentUser) {
        document.getElementById('authModal').classList.add('hidden');
        document.getElementById('appContent').classList.remove('hidden');
        app.initApp(currentUser);
    } else {
        app.showAuthModal();
    }
});


// Passkey Butonları
document.getElementById('passkeyAuthBtn').addEventListener('click', () => {
    // Passkey kimlik doğrulama kodunu buraya
});

document.getElementById('passwordFallbackBtn').addEventListener('click', () => {
    // Şifre fallback kodunu buraya
});

document.addEventListener("authSuccess", (e) => {
    const userData = e.detail;
    const greeting = document.getElementById("userGreeting");
    greeting.innerText = `Hoş geldin, ${userData.username || "user"}!`;
});
