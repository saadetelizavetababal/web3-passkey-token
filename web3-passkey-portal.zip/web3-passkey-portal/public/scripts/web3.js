export class Web3Auth {
  constructor() {
    this.walletAddress = '';
  }

  init() {
    document.getElementById('connectWallet').addEventListener('click', () => this.connectWallet());
    document.getElementById('getToken').addEventListener('click', () => this.getToken());
    document.getElementById('checkAccess').addEventListener('click', () => this.checkAccess());
  }

  async connectWallet() {
    if (typeof window.ethereum === "undefined") {
      alert("MetaMask not detected!");
      return;
    }

    const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
    this.walletAddress = accounts[0];

    document.getElementById("walletAddress").innerText = `Cüzdan Adresi: ${this.walletAddress}`;
    document.getElementById("getToken").disabled = false;
  }

  async getToken() {
    if (!this.walletAddress) return;

    const response = await fetch("http://localhost:4000/api/give-token", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ walletAddress: this.walletAddress })
    });

    const data = await response.json();
    document.getElementById("tokenBalance").innerText = `Token Miktarı: ${data.tokens}`;
    document.getElementById("checkAccess").disabled = false;
  }

  async checkAccess() {
    if (!this.walletAddress) return;

    const res = await fetch(`http://localhost:4000/api/user-level/${this.walletAddress}`);
    const data = await res.json();

    const accessStatus = document.getElementById("accessStatus");

    if (data.level === "Premium" || data.level === "Standard") {
      accessStatus.innerText = "Erişim verildi ✅";
      accessStatus.style.color = "green";
    } else {
      accessStatus.innerText = "Erişim reddedildi ❌";
      accessStatus.style.color = "red";
    }
  }
}
